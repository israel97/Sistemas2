/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import Modelos.Conectar;
import java.util.List;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

/**
 *
 * @author israel moo chable
 */
@Controller
public class ControllerVincFac {
     private JdbcTemplate jdbcTemplate;
     public ControllerVincFac(){
         Conectar con=new Conectar();
       this.jdbcTemplate=new JdbcTemplate(con.conectar());  
     }
     @RequestMapping("vincFac.htm")
     public ModelAndView VinculacionF(){//ModelAndView es una clase de java que nos permite renderizar vistas
        ModelAndView vincF= new ModelAndView();
        String articulo="SELECT idArticulo, institucion, nombreArt, fechPublicacionArt, ISSN,  nombrePartInterno, nombrePartExterno, autoresArt FROM productos.articulos natural join productos.producto natural join productos.convenio_producto natural join productos.convenio natural join productos.institucion where estadoProducto=1";
         List articulos= this.jdbcTemplate.queryForList(articulo);
         vincF.addObject("articulos",articulos);
         String evento="SELECT idEventos, institucion, nombreEvent, nombrePartInterno, nombrePartExterno FROM productos.eventos natural join productos.producto natural join productos.convenio_producto natural join productos.convenio natural join productos.institucion where estadoProducto=1";
         List eventos=this.jdbcTemplate.queryForList(evento);
         vincF.addObject("eventos",eventos);
         String patente="SELECT institucion,nombrePat,numeroPat, nombrePartInterno, nombrePartExterno FROM productos.patente natural join productos.producto natural join productos.convenio_producto natural join productos.convenio natural join productos.institucion where estadoProducto=1";
         List patentes=this.jdbcTemplate.queryForList(patente);
         vincF.addObject("patentes",patentes);
          String obra="SELECT institucion,nombreObraArt, nombrePartInterno, nombrePartExterno, patrocinador FROM productos.obras_artisticas natural join productos.producto natural join productos.convenio_producto natural join productos.convenio natural join productos.institucion where estadoProducto=1";
         List obras=this.jdbcTemplate.queryForList(obra);
         vincF.addObject("obras",obras);
           String memoria="SELECT institucion,nombreMemArb,ISBN, nombrePartInterno, nombrePartExterno FROM productos.memorias_arbitrarias natural join productos.producto natural join productos.convenio_producto natural join productos.convenio natural join productos.institucion where estadoProducto=1";
         List memorias=this.jdbcTemplate.queryForList(memoria);
         vincF.addObject("memorias",memorias);
         String ponencia="SELECT institucion, nombrePon, nombrePartInterno, nombrePartExterno  FROM productos.ponencia natural join productos.producto natural join productos.convenio_producto natural join productos.convenio natural join productos.institucion where estadoProducto=1";
         List ponencias=this.jdbcTemplate.queryForList(ponencia);
         vincF.addObject("ponencias",ponencias);
           String tesis="SELECT institucion,nombreTes, nombrePartInterno, nombrePartExterno FROM productos.tesis natural join productos.producto natural join productos.convenio_producto natural join productos.convenio natural join productos.institucion where estadoProducto=1";
         List Tesis=this.jdbcTemplate.queryForList(tesis);
         vincF.addObject("tesis",Tesis);
           String libro="SELECT institucion,nombreLib,ISBN, nombrePartInterno, nombrePartExterno FROM productos.libro natural join productos.producto natural join productos.convenio_producto natural join productos.convenio natural join productos.institucion where estadoProducto=1";
         List libros=this.jdbcTemplate.queryForList(libro);
         vincF.addObject("libros",libros);
           String prototipo="SELECT institucion,nombreProt, nombrePartExterno FROM productos.prototipo natural join productos.producto natural join productos.convenio_producto natural join productos.convenio natural join productos.institucion where estadoProducto=1";
         List prototipos=this.jdbcTemplate.queryForList(prototipo);
         vincF.addObject("prototipos",prototipos);
           String estancia="SELECT institucion,nombreInv, nombrePartInterno, tipoInv, patrocinadorInv FROM productos.estancia_investigacion natural join productos.producto natural join productos.convenio_producto natural join productos.convenio natural join productos.institucion where estadoProducto=1";
         List estancias=this.jdbcTemplate.queryForList(estancia);
         vincF.addObject("estancias",estancias);
           String capacitacion="SELECT institucion,nombreCap, nombrePartInterno, tipo_capacitacion, patrocinadorCap FROM productos.capacitacion natural join productos.producto natural join productos.convenio_producto natural join productos.convenio natural join productos.institucion where estadoProducto=1";
         List capacitaciones=this.jdbcTemplate.queryForList(capacitacion);
         vincF.addObject("capacitaciones",capacitaciones);
           String movilidad="SELECT institucion, nombrePartInterno, tipoMov, patrocinadorMov FROM productos.movilidad natural join productos.producto natural join productos.convenio_producto natural join productos.convenio natural join productos.institucion where estadoProducto=1";
         List movilidades=this.jdbcTemplate.queryForList(movilidad);
         vincF.addObject("movilidades",movilidades);
           String informe="SELECT institucion,nombreInf, nombrePartInterno, nombrePartExterno FROM productos.informe_técnico natural join productos.producto natural join productos.convenio_producto natural join productos.convenio natural join productos.institucion where estadoProducto=1";
         List informes=this.jdbcTemplate.queryForList(informe);
         vincF.addObject("informes",informes);
         String proyecto="SELECT institucion, nombreProy, nombrePartInterno, nombrePartExterno  FROM productos.proyecto natural join productos.producto natural join productos.convenio_producto natural join productos.convenio natural join productos.institucion where estadoProducto=1";
         List proyectos=this.jdbcTemplate.queryForList(proyecto);
         vincF.addObject("proyectos",proyectos);
         vincF.setViewName("VincFac");//indica cual es el nombre de la vista que estará asociada al método.
        
        return vincF;
    }
    
}
