/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.sql.*;
import javax.servlet.http.HttpSession;

/**
 *
 * @author israel moo chable
 */

public class Controllerlogin extends HttpServlet {
    public boolean sesionC;
    public void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
             HttpSession sesion= request.getSession();
            String _username=request.getParameter("usuario");
            String _password=request.getParameter("contra");
            String vingral="nombre1";
            String pass="root1";
            String vinfac="nombre2";
            String pass2="root2";
            String coordi="nombre3";
            String pass3="root3";
            try
            {
               if(!_username.equals("") && !_password.equals(""))
               {
                   Class.forName("com.mysql.jdbc.Driver").newInstance();
                   Connection conn=DriverManager.getConnection("jdbc:mysql://localhost/productos","root","");
                   String Query="select * from login where nombreLog=?  and contraseñaLog=? ";
                   PreparedStatement psm=conn.prepareStatement(Query);
                   psm.setString(1, _username);
                   psm.setString(2, _password);
                   ResultSet rs= psm.executeQuery();
                   if(rs.next())
                   { 
                       if(_username.equals(vingral) && _password.equals(pass)){
                            response.sendRedirect("vincGral.htm");
                            } else if(_username.equals(vinfac) && _password.equals(pass2)){
                                response.sendRedirect("vincFac.htm?ingenieria");
                            }   else if(_username.equals(coordi) && _password.equals(pass3)){
                                response.sendRedirect("coordi.htm");
                                    }
                   }else{
                       response.sendRedirect("login.htm?error");
                         }
               }else{
                   response.sendRedirect("login.htm?vacio");
               }
            }
            catch(Exception ex)
            {
                out.println("Exception :"+ex.getMessage());
            }
        }
    }
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }
     protected void processRequestGET(HttpServletRequest request, HttpServletResponse response)
         throws ServletException, IOException {
     String action=(request.getPathInfo()!=null?request.getPathInfo():"");
     HttpSession sesion= request.getSession();
     if(action.equals("login.htm?out")){
         sesion.invalidate();
         response.sendRedirect("login.htm");
     }
     }

public Controllerlogin(){
}
public boolean getSesion(){
 return this.sesionC;
}
}
