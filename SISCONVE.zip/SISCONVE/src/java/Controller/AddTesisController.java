/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import Modelos.Conectar;
import Modelos.Tesis;
import Modelos.ValidarTesis;
import java.util.LinkedHashMap;
import java.util.Map;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.support.SessionStatus;
import org.springframework.web.servlet.ModelAndView;

/**
 *
 * @author israel moo chable
 */
@Controller
@RequestMapping("addTesis.htm")
public class AddTesisController {
       ValidarTesis validartesis;
       private JdbcTemplate jdbcTemplate;
       
       public AddTesisController()
    {
        this.validartesis=new ValidarTesis();
        Conectar con=new Conectar();
        this.jdbcTemplate=new JdbcTemplate(con.conectar());
    }
 @RequestMapping(method=RequestMethod.GET)
    public ModelAndView form(){
        
        ModelAndView mav=new ModelAndView();
        mav.setViewName("addTesis");
        mav.addObject("tesis", new Tesis());
        return mav;
    }
    @RequestMapping(method=RequestMethod.POST)
    public ModelAndView form(
    @ModelAttribute("tesis") Tesis a,
            BindingResult result,
            SessionStatus status
    )
    {   
        this.validartesis.validate(a, result);
        if(result.hasErrors()){
            ModelAndView mav= new ModelAndView();
            mav.setViewName("addTesis");
            mav.addObject("tesis", new Tesis());
            return mav;
        }else{
            //this.jdbcTemplate.update("insert into employees (idEmployees,name,lastname,Curp,phone,age,estado) values(?,?,?,?,?,?,?)",
             // a.getId(),a.getName(),a.getLastName(),a.getCurp(),a.getPhone(),a.getAge(),a.getEstado()
           // );
            return new ModelAndView("redirect:consultas.htm");
        }
        
    }
    //Metodo para rellenar el select de instituciones
    @ModelAttribute("instituciones")
    public Map<String,String> listaInstituciones()
    {        
        Map<String,String> institucion=new LinkedHashMap<>();
        institucion.put("1","institución 1");
        institucion.put("2","institución 2");
        institucion.put("3","institución 3");
        institucion.put("4","institución 4");
        institucion.put("5","institución 5");
        return institucion;
    }
    //Metodo para rellenar el select de convenios
    @ModelAttribute("convenios")
    public Map<String,String> listaConvenios()
    {        
        Map<String,String> convenios=new LinkedHashMap<>();
        convenios.put("1","convenio 1");
        convenios.put("2","convenio 2");
        convenios.put("3","convenio 3");
        convenios.put("4","convenio 4");
        convenios.put("5","convenio 5");
        return convenios;
    }
    
}
