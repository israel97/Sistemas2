/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import Modelos.Conectar;
import java.util.List;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

/**
 *
 * @author israel moo chable
 */
@Controller
public class ControllerVincGral {
     private JdbcTemplate jdbcTemplate;
   public ControllerVincGral(){
       Conectar con=new Conectar();
       this.jdbcTemplate=new JdbcTemplate(con.conectar());
   }
     @RequestMapping("vincGral.htm")
     public ModelAndView VinculacionG(){//ModelAndView es una clase de java que nos permite renderizar vistas
        ModelAndView vincG= new ModelAndView();
         String sql="select * from productos.artículos"; 
          List datos= this.jdbcTemplate.queryForList(sql);
        vincG.addObject("datos",datos);
        vincG.setViewName("VincGral");//indica cual es el nombre de la vista que estará asociada al método.
        //log.addObject("persona", new Persona());
        return vincG;
    }
}
