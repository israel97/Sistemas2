/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import Modelos.Articulos;
import Modelos.Conectar;
import Modelos.Patentes;
import Modelos.ValidarArticulos;
import Modelos.ValidarPatentes;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.support.SessionStatus;
import org.springframework.web.servlet.ModelAndView;

/**
 *
 * @author israel moo chable
 */
@Controller
@RequestMapping("addPatente.htm")
public class AddPatenteController {
     ValidarPatentes validarpatente;
       private JdbcTemplate jdbcTemplate;
       
       public AddPatenteController()
    {
        this.validarpatente=new ValidarPatentes();
        Conectar con=new Conectar();
        this.jdbcTemplate=new JdbcTemplate(con.conectar());
    }
 @RequestMapping(method=RequestMethod.GET)
    public ModelAndView form(){
        
        ModelAndView mav=new ModelAndView();
        mav.setViewName("addPatente");
        mav.addObject("patente", new Patentes());
        return mav;
    }
    @RequestMapping(method=RequestMethod.POST)
    public ModelAndView form(
    @ModelAttribute("patente") Patentes a,
            BindingResult result,
            SessionStatus status
    )
    {   
        this.validarpatente.validate(a, result);
        if(result.hasErrors()){
            ModelAndView mav= new ModelAndView();
            mav.setViewName("addPatente");
            mav.addObject("patente", new Patentes());
            return mav;
        }else{
            /*
            this.jdbcTemplate.update("INSERT INTO `productos`.`articulos` (`nombreArt`, `ISSN`, `autoresArt`, `fechPublicacionArt`) VALUES (?, ?, ?, ?)",
              a.getNombre(),a.getIssn(),a.getAutores(),a.getAño()
           );
            String idarticulo="SELECT idArticulo FROM productos.articulos ORDER by idArticulo DESC LIMIT 1";
            List idArticulo=this.jdbcTemplate.queryForList(idarticulo);
            this.jdbcTemplate.update("INSERT INTO `productos`.`producto` (`idArticulo`, `idCarrera`, `nombrePartInterno`, `nombrePartExterno`) VALUES ( ?,"+idArticulo+", ?, ?)",
            a.getId(),a.getPartinterno(),a.getPartexterno()
            );
            this.jdbcTemplate.update("INSERT INTO `productos`.`convenio_producto` (`idConvenio`) VALUES (?)",
                    a.getConvenios());*/
            return new ModelAndView("redirect:consultas.htm");
        }
        
    }
    //Metodo para rellenar el select de convenios
    @ModelAttribute("convenios")
    public Map<String,String> listaConvenios()
    {        
        Map<String,String> convenios=new LinkedHashMap<>();
        convenios.put("9","convenio 1");
        convenios.put("10","convenio 2");
        convenios.put("11","convenio 3");
        convenios.put("12","convenio 4");
        convenios.put("13","convenio 5");
        return convenios;
    }
    @ModelAttribute("carreras")
    public Map<String,String> listaCarreras()
    {        
        Map<String,String> carreras=new LinkedHashMap<>();
        carreras.put("9","carrera 1");
        carreras.put("10","carrera 2");
        carreras.put("11","carrera 3");
        carreras.put("12","carrera 4");
        carreras.put("13","carrera 5");
        return carreras;
    }
    
}
