/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import Modelos.Articulos;
import Modelos.Conectar;
import Modelos.Ponencias;
import Modelos.ValidarArticulos;
import Modelos.ValidarPonencias;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.support.SessionStatus;
import org.springframework.web.servlet.ModelAndView;

/**
 *
 * @author israel moo chable
 */
@Controller
@RequestMapping("editPonencia.htm")
public class EditPonenciaController {
    ValidarPonencias validarponencias;
       private JdbcTemplate jdbcTemplate;
       
   
    public EditPonenciaController()
    {
       this.validarponencias=new ValidarPonencias();
        Conectar con=new Conectar();
        this.jdbcTemplate=new JdbcTemplate(con.conectar());
    }
    @RequestMapping(method=RequestMethod.GET) 
     public ModelAndView form(/*HttpServletRequest request*/){
        
        ModelAndView mav=new ModelAndView();
       // int id= Integer.parseInt(request.getParameter("id"));
        //Articulos datos= this.selectArticulo(id);
        mav.setViewName("editPonencia");
       // mav.addObject("employees", new Articulos(id, datos.getName(),datos.getLastName(),datos.getCurp(),datos.getPhone(),datos.getAge()));
       mav.addObject("ponencia", new Ponencias());//eliminar 
       return mav;
    }
      @RequestMapping(method=RequestMethod.POST) 
     public ModelAndView form (
        
        @ModelAttribute("ponencia") Ponencias a,
       BindingResult result,
            SessionStatus status//,
            //HttpServletRequest request
            )
     {
         this.validarponencias.validate(a, result);
         if(result.hasErrors())
         {
             ModelAndView mav=new ModelAndView();
       // int id= Integer.parseInt(request.getParameter("id"));
       // Articulos datos= this.selectArticulo(id);
        mav.setViewName("editPonencia");
       // mav.addObject("articulo", new Articulos(id, datos.getName(),datos.getLastName(),datos.getCurp(),datos.getPhone(),datos.getAge()));
        mav.addObject("ponencia", new Ponencias());//eliminar 
       return mav; 
         }/*else
         {
             int id= Integer.parseInt(request.getParameter("id"));
             this.jdbcTemplate.update("update employees "
                     + "set name=?,"
                     +"lastname=?,"
                     +"Curp=?,"
                     +"phone=?,"
                     +"age=? "
                     + "Where "
                     +"idEmployees=? ",
                    a.getName(), a.getLastName(), a.getCurp(), a.getPhone(), a.getAge(),id);
             return new ModelAndView("redirect:consultas.htm");
         }*/
         return new ModelAndView("redirect:editPonencia.htm");//eliminar cuando quite los comentarios de arriba
     }


    /*public Articulos selectArticulo(int id) {
        final Articulos articulo= new Articulos();
        String Sql= "SELECT * FROM employees WHERE idEmployees='"+ id+"'";
        return (Articulos) jdbcTemplate.query(Sql, new ResultSetExtractor<Articulos>()
        {
            public Articulos extractData(ResultSet rs) throws SQLException, DataAccessException 
            {
                if (rs.next()) 
                {
                    articulo.setName(rs.getString("Name"));
                    articulo.setLastName(rs.getString("LastName"));
                    articulo.setCurp(rs.getString("Curp"));
                    articulo.setPhone(rs.getString("Phone"));
                    articulo.setAge(rs.getString("Age"));
                }
                return articulo;
            }
        }
        
        );
        
    }*/
}
