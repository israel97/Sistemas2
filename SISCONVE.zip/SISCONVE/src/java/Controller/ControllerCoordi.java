/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
/**
 *
 * @author israel moo chable
 */

public class ControllerCoordi {
    /*public boolean sesionC(){
        boolean decision;
    Controllerlogin sesionC= new Controllerlogin();
    decision=sesionC.getSesion();
    return decision;
    }*/
    @RequestMapping("coordi.htm")
    public ModelAndView coordinacion(HttpServletRequest request, HttpServletResponse resp){//ModelAndView es una clase de java que nos permite renderizar vistas
      /* String _username=request.getParameter("usuario");
       String _password=request.getParameter("contra");
       String usuario="nombre3";
       String contra="root3";
       if(_username!=null && _password!=null){
           if(_username.equals(usuario) && _password.equals(contra)){*/
           ModelAndView cordi= new ModelAndView();
        cordi.setViewName("Coordi");
        return cordi;
           }
       //}
     // else return new ModelAndView("redirect:/login.htm");
   // }

}
