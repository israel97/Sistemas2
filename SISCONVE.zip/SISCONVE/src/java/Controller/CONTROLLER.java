
package Controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

/**
 *
 * @author israel moo chable
 */
    @Controller//para informar al framework que esta clase que sera usada como un controlador

 public class CONTROLLER{
    
  //informar al framework que este método será usada como una vista, lo que se escribe para entrar a la vista
    @RequestMapping("login.htm")
    public ModelAndView login(){//ModelAndView es una clase de java que nos permite renderizar vistas
        ModelAndView log= new ModelAndView();
        log.setViewName("Login");//indica cual es el nombre de la vista que estará asociada al método.
        //log.addObject("persona", new Persona());
        return log;
    }
   /* public void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
             HttpSession sesion= request.getSession();
            String _username=request.getParameter("usuario");
            String _password=request.getParameter("contra");
            String vingral="nombre1";
            String pass="root1";
            String vinfac="nombre2";
            String pass2="root2";
            String coordi="nombre3";
            String pass3="root3";
            try
            {
               if(!_username.equals("") && !_password.equals(""))
               {
                   Class.forName("com.mysql.jdbc.Driver").newInstance();
                   Connection conn=DriverManager.getConnection("jdbc:mysql://localhost/productos","root","");
                   String Query="select * from login where nombre=?  and contraseña=? ";
                   PreparedStatement psm=conn.prepareStatement(Query);
                   psm.setString(1, _username);
                   psm.setString(2, _password);
                   ResultSet rs= psm.executeQuery();
                   if(rs.next())
                   { 
                       if(_username.equals(vingral) && _password.equals(pass)){
                            response.sendRedirect("vincGral.htm");
                            } else if(_username.equals(vinfac) && _password.equals(pass2)){
                                response.sendRedirect("vincFac.htm");
                            }   else if(_username.equals(coordi) && _password.equals(pass3)){
                                response.sendRedirect("coordi.htm");
                                    }
                   }else{
                       response.sendRedirect("login.htm?error");
                         }
               }else{
                   response.sendRedirect("login.htm?vacio");
               }
            }
            catch(Exception ex)
            {
                out.println("Exception :"+ex.getMessage());
            }
        }
    }*/
    
}
