/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

/**
 *
 * @author israel moo chable
 */
public class ControllerDirec {
    @RequestMapping("direc.htm")
     public ModelAndView Director(){//ModelAndView es una clase de java que nos permite renderizar vistas
        ModelAndView direc= new ModelAndView();
        direc.setViewName("Direc");//indica cual es el nombre de la vista que estará asociada al método.
        //log.addObject("persona", new Persona());
        return direc;
    }
    
}
