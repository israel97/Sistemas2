/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelos;

/**
 *
 * @author israel moo chable
 */
public class Articulos {
    private String Convenios,Instituciones,Nombre,Carrera;
    private int id ,Issn,Año,Estado;
    private String Partinterno,Partexterno,Autores;
    public Articulos() {
    }

    public Articulos(int id, String Convenios,String Carrera, String Nombre, int Año, int ISSN, String Partinterno, String Partexterno, String Autores) {
        this.id = id;
        this.Carrera=Carrera;
        this.Convenios= Convenios;
        this.Nombre = Nombre;
        this.Año = Año;
        this.Issn = ISSN;
        this.Partinterno = Partinterno;
        this.Partexterno = Partexterno;
        this.Autores = Autores;
    }
    public Articulos(String Convenios,String Instituciones, String Nombre, int Año, int ISSN, String Partinterno, String Partexterno, String Autores) {
        this.Convenios= Convenios;
        this.Instituciones = Instituciones;
        this.Nombre = Nombre;
        this.Año = Año;
        this.Issn = ISSN;
        this.Partinterno = Partinterno;
        this.Partexterno = Partexterno;
        this.Autores = Autores;
    }
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
    public String getCarrera() {
        return Carrera;
    }

    public void setCarrera(String Carrera) {
        this.Carrera = Carrera;
    }

    public String getConvenios(){
        return Convenios;
    }
    
    public void setConvenios(String Convenios){
    this.Convenios=Convenios;    
    } 
    
    public String getInstituciones() {
        return Instituciones;
    }

    public void setInstituciones(String Instituciones) {
        this.Instituciones = Instituciones;
    }

    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }

    public int getAño() {
        return Año;
    }
    

    public void setAño(int Año) {
        this.Año = Año;
    }

    public int getIssn() {
        return Issn;
    }

    public void setIssn(int Issn) {
        this.Issn = Issn;
    }

    public String getPartinterno() {
        return Partinterno;
    }

    public void setPartinterno(String Partinterno) {
        this.Partinterno = Partinterno;
    }

    public String getPartexterno() {
        return Partexterno;
    }

    public void setPartexterno(String Partexterno) {
        this.Partexterno = Partexterno;
    }

    public String getAutores() {
        return Autores;
    }

    public void setAutores(String Autores) {
        this.Autores = Autores;
    }

  
}
