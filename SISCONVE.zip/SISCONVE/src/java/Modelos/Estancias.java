/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelos;

/**
 *
 * @author israel moo chable
 */
public class Estancias {
    private String Convenios,Carrera,Instituciones,Partinterno,Tipo,Patrocinadores;
    private int id, Estado;

    public Estancias() {
    }

    public String getConvenios() {
        return Convenios;
    }

    public void setConvenios(String Convenios) {
        this.Convenios = Convenios;
    }

    public String getCarrera() {
        return Carrera;
    }

    public void setCarrera(String Carrera) {
        this.Carrera = Carrera;
    }

    public String getInstituciones() {
        return Instituciones;
    }

    public void setInstituciones(String Instituciones) {
        this.Instituciones = Instituciones;
    }

    public String getPartinterno() {
        return Partinterno;
    }

    public void setPartinterno(String Partinterno) {
        this.Partinterno = Partinterno;
    }

    public String getTipo() {
        return Tipo;
    }

    public void setTipo(String Tipo) {
        this.Tipo = Tipo;
    }

    public String getPatrocinadores() {
        return Patrocinadores;
    }

    public void setPatrocinadores(String Patrocinadores) {
        this.Patrocinadores = Patrocinadores;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getEstado() {
        return Estado;
    }

    public void setEstado(int Estado) {
        this.Estado = Estado;
    }
    
}
