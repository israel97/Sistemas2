/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelos;

import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;
/**
 *
 * @author israel moo chable
 */
public class ValidarTesis implements Validator{
     @Override
    public boolean supports(Class<?> type) {
        return Articulos.class.isAssignableFrom(type);
    }

    @Override
    public void validate(Object o, Errors errors) {
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "convenios", "required.convenios","Agrege el convenio");
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "nombre", "required.nombre","Escriba el nombre del artículo");
         ValidationUtils.rejectIfEmptyOrWhitespace(errors, "año", "required.año","Agregue el año del Artículo");
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "issn", "required.issn","Agregue el ISSN del artículo");
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "partinterno", "required.partinterno","Agregue el participante interno del artículo");
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "partexterno", "required.partexterno","Agregue el participante externo del artículo");
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "autores", "required.autores","Agregue los autores");
        
    }
    
}

