/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelos;

/**
 *
 * @author israel moo chable
 */
public class Patentes {
  private String Convenios,Carrera,Instituciones,Nombre,Partinterno,Partexterno;  
private int id, Estado,Numero;

    public Patentes() {
    }

    public String getConvenios() {
        return Convenios;
    }

    public void setConvenios(String Convenios) {
        this.Convenios = Convenios;
    }

    public String getCarrera() {
        return Carrera;
    }

    public void setCarrera(String Carrera) {
        this.Carrera = Carrera;
    }

    public String getInstituciones() {
        return Instituciones;
    }

    public void setInstituciones(String Instituciones) {
        this.Instituciones = Instituciones;
    }

    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }

    public String getPartinterno() {
        return Partinterno;
    }

    public void setPartinterno(String Partinterno) {
        this.Partinterno = Partinterno;
    }

    public String getPartexterno() {
        return Partexterno;
    }

    public void setPartexterno(String Partexterno) {
        this.Partexterno = Partexterno;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getEstado() {
        return Estado;
    }

    public void setEstado(int Estado) {
        this.Estado = Estado;
    }

    public int getNumero() {
        return Numero;
    }

    public void setNumero(int Numero) {
        this.Numero = Numero;
    }

}
